import React from 'react'
import AddPlayList from '../Components/AddPlayList'

function page() {
  return (
    <AddPlayList/>
  )
}

export default page