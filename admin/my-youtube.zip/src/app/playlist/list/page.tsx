import React from 'react'
import ViewAllPlayList from '../Components/ViewAllPlayList'

function page() {
  return (
   <ViewAllPlayList/>
  )
}

export default page