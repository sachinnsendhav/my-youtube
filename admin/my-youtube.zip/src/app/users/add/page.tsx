import React from 'react'
import CreateUser from '../Components/CreateUser'

function page() {
  return (
    <CreateUser/>
  )
}

export default page