import React from 'react'
import AllUsersList from '../Components/AllUsersList'

function page() {
  return (
   <AllUsersList/>
  )
}

export default page