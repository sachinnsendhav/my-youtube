import SignIn from "../component/SignIn"

function page() {
    return (
        <SignIn />
    )
}

export default page