
import React from 'react'
import Signup from '../component/Signup'

function page() {
    return (
        <Signup />
    )
}

export default page