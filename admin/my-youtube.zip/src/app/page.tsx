import { Dashboard } from "./components";

export default function Home() {
  return (
    <Dashboard />
  )
}